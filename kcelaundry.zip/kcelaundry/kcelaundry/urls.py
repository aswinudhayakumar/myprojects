"""kcelaundry URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf.urls import url
from django.http import HttpResponseRedirect
from django.views import View
from laundry.views import *
from django.views.generic import TemplateView
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    url(r'^login/$', LoginView.as_view(), name='login'),
    url(r'^logout/$', LogoutView.as_view(), name='logout'),
    url(r'^admin/', admin.site.urls),
    url(r'^add/$', laundry_createview),
    url(r'^$', TemplateView.as_view(template_name='home.html')),
    url(r'^proclo/$', proclo.as_view()),
    url(r'^proclo/(?P<slug>\w+)/$', proclo.as_view()),
    url(r'^outclo/$', outclo.as_view()),
    url(r'^outclo/(?P<slug>\w+)/$', outclo.as_view()),
    url(r'^success/$', success.as_view()),
    url(r'^success/(?P<slug>\w+)/$', success.as_view()),
    url(r'^comp/$', comp.as_view()),
    url(r'^comp/(?P<slug>\w+)/$', comp.as_view()),
    url(r'^toout/(?P<id>\d+)/$', toout),
    url(r'^tosuccess/(?P<id>\d+)/$', tosuccess),
    url(r'^tocomp/(?P<id>\d+)/$', tocomp),
    url(r'^fcts/(?P<id>\d+)/$', fcts),

]
