from django.db import models
from django.conf import settings


# Create your models here.

class LaundryService(models.Model):
    name = models.CharField(max_length=150)
    rollno = models.CharField(max_length=6)
    year = models.CharField(max_length=50)
    dept = models.CharField(max_length=50)
    shirt = models.CharField(max_length=50, default=0)
    pant = models.CharField(max_length=50, default=0)
    tshirt = models.CharField(max_length=50, default=0)
    trouser = models.CharField(max_length=50, default=0)
    total = models.CharField(max_length=50, default=0)
    timestamp = models.DateTimeField(auto_now_add=True)
    category = models.CharField(max_length=50, default=0)
    def __str__(self):
        return self.name
