from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from .models import *
from .forms import *
from django.db.models import Q
from django.views.generic import TemplateView, ListView, UpdateView, CreateView


# Create your views here.
class proclo(ListView):
    template_name = 'laundry/proclo.html'

    def get_queryset(self):
        slug = self.kwargs.get("slug")
        if slug:
            queryset = LaundryService.objects.filter(
                Q(dept__iexact=slug) &
                Q(category__icontains=0)
            )
        else:
            queryset = LaundryService.objects.filter(category__icontains=0)

        return queryset


class outclo(ListView):
    template_name = 'laundry/outclo.html'

    def get_queryset(self):
        slug = self.kwargs.get("slug")
        if slug:
            queryset = LaundryService.objects.filter(
                Q(dept__iexact=slug) &
                Q(category__icontains=1)
            )
        else:
            queryset = LaundryService.objects.filter(category__icontains=1)

        return queryset


class success(ListView):
    template_name = 'laundry/success.html'

    def get_queryset(self):
        slug = self.kwargs.get("slug")
        if slug:
            queryset = LaundryService.objects.filter(
                Q(dept__iexact=slug) &
                Q(category__icontains=2)
            )
        else:
            queryset = LaundryService.objects.filter(category__icontains=2)

        return queryset


class comp(ListView):
    template_name = 'laundry/comp.html'

    def get_queryset(self):
        slug = self.kwargs.get("slug")
        if slug:
            queryset = LaundryService.objects.filter(
                Q(dept__iexact=slug) &
                Q(category__icontains=3)
            )
        else:
            queryset = LaundryService.objects.filter(category__icontains=3)

        return queryset


def laundry_createview(request):
    if request.user.is_authenticated:
        template_name = 'laundry/forms.html'
        form = LaundryCreateForm(request.POST)
        if form.is_valid():
            obj = LaundryService.objects.create(
                name=form.cleaned_data.get('name'),
                rollno=form.cleaned_data.get('rollno'),
                year=form.cleaned_data.get('year'),
                dept=form.cleaned_data.get('dept'),
                shirt=form.cleaned_data.get('shirt'),
                pant=form.cleaned_data.get('pant'),
                tshirt=form.cleaned_data.get('tshirt'),
                trouser=form.cleaned_data.get('trouser'),
                total=int(form.cleaned_data.get('shirt')) + int(form.cleaned_data.get('pant')) + int(
                    form.cleaned_data.get('tshirt')) + int(form.cleaned_data.get('trouser')),
            )
        context = {}
        return render(request, template_name, context)
    else:
        return HttpResponseRedirect('/')


def toout(requset, id):
    import datetime
    x = LaundryService.objects.filter(pk=id)
    ti = datetime.datetime.now()
    for i in x:
        i.category = 1
        i.timestamp = str(ti)
        i.save()
    return HttpResponseRedirect('/proclo/')


def tosuccess(requset, id):
    import datetime
    x = LaundryService.objects.filter(pk=id)
    ti = datetime.datetime.now()
    for i in x:
        i.category = 2
        i.timestamp = str(ti)
        i.save()
    return HttpResponseRedirect('/outclo/')


def tocomp(requset, id):
    import datetime
    x = LaundryService.objects.filter(pk=id)
    ti = datetime.datetime.now()
    for i in x:
        i.category = 3
        i.timestamp = str(ti)
        i.save()
    return HttpResponseRedirect('/outclo/')

def fcts(requset, id):
    import datetime
    x = LaundryService.objects.filter(pk=id)
    ti = datetime.datetime.now()
    for i in x:
        i.category = 2
        i.timestamp = str(ti)
        i.save()
    return HttpResponseRedirect('/comp/')
