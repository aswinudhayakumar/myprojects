from django.apps import AppConfig


class LaundryConfig(AppConfig):
    name = 'laundry'
