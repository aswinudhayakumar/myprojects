from django import forms
from .models import *


class LaundryCreateForm(forms.Form):
    name = forms.CharField()
    year = forms.CharField()
    rollno = forms.CharField()
    dept = forms.CharField()
    shirt = forms.CharField()
    tshirt = forms.CharField()
    pant = forms.CharField()
    trouser = forms.CharField()
